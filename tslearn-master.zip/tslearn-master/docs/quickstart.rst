Quick-start guide
=================

For a list of functions and classes available in ``tslearn``, please have a
look at our :doc:`API Reference <reference>`.

.. toctree::
    :maxdepth: 2

    installation
    gettingstarted
    variablelength
    integration_other_software
    contributing
