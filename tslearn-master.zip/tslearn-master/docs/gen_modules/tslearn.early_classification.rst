.. _mod-early_classification:

tslearn.early_classification
============================

.. automodule:: tslearn.early_classification

   .. rubric:: Classes

   .. autosummary::
      :toctree: early_classification
      :template: class.rst
   
      NonMyopicEarlyClassifier

