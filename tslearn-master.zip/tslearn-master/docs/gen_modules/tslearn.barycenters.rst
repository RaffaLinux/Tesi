.. _mod-barycenters:

tslearn.barycenters
===================

.. automodule:: tslearn.barycenters

   .. rubric:: Functions

   .. autosummary::
      :toctree: barycenters
      :template: function.rst

      euclidean_barycenter
      dtw_barycenter_averaging
      dtw_barycenter_averaging_subgradient
      softdtw_barycenter

