.. _mod-shapelets:

tslearn.shapelets
=================

.. automodule:: tslearn.shapelets

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: shapelets
      :template: function.rst
   
      grabocka_params_to_shapelet_size_dict
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: shapelets
      :template: class.rst
   
      LearningShapelets
   
   

   
   
   