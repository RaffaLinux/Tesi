.. _mod-piecewise:

tslearn.piecewise
=================

.. automodule:: tslearn.piecewise
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: piecewise
      :template: class.rst
   
      OneD_SymbolicAggregateApproximation
      PiecewiseAggregateApproximation
      SymbolicAggregateApproximation
   
   

   
   
   