.. _mod-neighbors:

tslearn.neighbors
=================

.. automodule:: tslearn.neighbors
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: neighbors
      :template: class.rst
   
      KNeighborsTimeSeries
      KNeighborsTimeSeriesClassifier
      KNeighborsTimeSeriesRegressor
   
   

   
   
   