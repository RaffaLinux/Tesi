.. _mod-neural_network:

tslearn.neural_network
======================

.. automodule:: tslearn.neural_network

   .. rubric:: Classes

   .. autosummary::
      :toctree: neural_network
      :template: class.rst
   
      TimeSeriesMLPClassifier
      TimeSeriesMLPRegressor

