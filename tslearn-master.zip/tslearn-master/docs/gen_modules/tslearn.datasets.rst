.. _mod-datasets:

tslearn.datasets
================

.. automodule:: tslearn.datasets
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: datasets
      :template: class.rst
   
      UCR_UEA_datasets
      CachedDatasets
   
   

   
   
   