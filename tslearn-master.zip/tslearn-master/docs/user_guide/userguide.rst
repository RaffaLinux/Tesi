User Guide
==========

.. toctree::
    :maxdepth: 2

    dtw
    kernel
    clustering
    shapelets
    matrix-profile
    early
