.. _fun-{{ fullname }}:

{{ fullname | underline }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. include:: ../backreferences/{{fullname}}.examples

.. raw:: html

     <div style='clear:both'></div>
